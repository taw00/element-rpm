/*
 * skin-sdk.js
 *
 * Skins the react-sdk with the vector components
 */

import * as sdk from "matrix-react-sdk";
import * as skin from "../src/component-index";
sdk.loadSkin(skin);
