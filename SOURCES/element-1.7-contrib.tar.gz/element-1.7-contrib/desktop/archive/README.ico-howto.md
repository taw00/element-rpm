An .ico file is a microsoft windows icon file. I don't know what uses it on linux, but I have been keeping it updated.

To convert...
```
# install ImageMagick
sudo dnf install ImageMagick -y

# convert png to ico
convert hicolor-256-io.element.Element.png hicolor-256-io.element.Element.ico
```
