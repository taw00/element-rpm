/*
Copyright 2017 OpenMarket Ltd

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

const path = require('path');
const spawn = require('child_process').spawn;
const {app} = require('electron');
const fsProm = require('fs').promises;

function runUpdateExe(args) {
    // Invokes Squirrel's Update.exe which will do things for us like create shortcuts
    // Note that there's an Update.exe in the app-x.x.x directory and one in the parent
    // directory: we need to run the one in the parent directory, because it discovers
    // information about the app by inspecting the directory it's run from.
    const updateExe = path.resolve(path.dirname(process.execPath), '..', 'Update.exe');
    console.log(`Spawning '${updateExe}' with args '${args}'`);
    return new Promise(resolve => {
        spawn(updateExe, args, {
          detached: true,
        }).on('close', resolve);
    });
}

function checkSquirrelHooks() {
    if (process.platform !== 'win32') return false;

    const cmd = process.argv[1];
    const target = path.basename(process.execPath);
    if (cmd === '--squirrel-install' || cmd === '--squirrel-updated') {
        Promise.resolve().then(() => {
            return runUpdateExe(['--createShortcut=' + target]);
        }).then(() => {
            // remove the old 'Riot' shortcuts, if they exist (update.exe --removeShortcut doesn't work
            // because it always uses the name of the product as the name of the shortcut: the only variable
            // is what executable you're linking to)
            const appDataDir = process.env.APPDATA;
            if (!appDataDir) return;
            const startMenuDir = path.join(
                appDataDir, 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'New Vector Ltd',
            );
            return fsProm.rmdir(startMenuDir, { recursive: true });
        }).then(() => {
            const oldDesktopShortcut = path.join(app.getPath('desktop'), 'Riot.lnk');
            return fsProm.unlink(oldDesktopShortcut).catch(() => {});
        }).then(() => {
            app.quit();
        });
        return true;
    } else if (cmd === '--squirrel-uninstall') {
        runUpdateExe(['--removeShortcut=' + target]).then(() => {
            app.quit();
        });
        return true;
    } else if (cmd === '--squirrel-obsolete') {
        app.quit();
        return true;
    }
    return false;
}

module.exports = checkSquirrelHooks;
